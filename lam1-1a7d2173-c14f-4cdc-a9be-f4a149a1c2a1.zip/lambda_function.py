import json
import logging
import boto3


dynamodb_client = boto3.client('dynamodb')

def lambda_handler(event, context):
    
    data = event["body"]
    Item=json.loads(data)
    
    message = f"Success \nthe data i git from you is \n {data}"
    
        


    return message
